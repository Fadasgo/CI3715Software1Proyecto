""" Posts application module"""
from django.apps import AppConfig


class PostsConfig(AppConfig):
    """ Posts application settings"""
    name = 'posts'
    varbose_name = 'Posts'
